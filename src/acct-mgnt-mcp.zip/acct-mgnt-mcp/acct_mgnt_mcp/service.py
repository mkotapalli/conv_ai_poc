from __future__ import annotations

from mcp.server.fastmcp import FastMCP
from starlette.requests import Request
from starlette.responses import JSONResponse

# ---------------- MCP Server ----------------
MCP_SERVER = FastMCP(
    name="acct-mgnt-mcp",
    instructions="Account management MCP server",
    host="0.0.0.0",
    port=8083,
    streamable_http_path="/mcp",
    stateless_http=True,
    log_level="DEBUG",
)


# ---------------- Health endpoint ----------------
@MCP_SERVER.custom_route("/health", methods=["GET"], include_in_schema=False)
async def health(_: Request) -> JSONResponse:
    return JSONResponse({"status": "ok"})


# ---------------- TOOL (IMPORTANT: must be defined at import time) ----------------
@MCP_SERVER.tool(
    name="orchestrator_invoke",
    description="Invoke orchestrator agent"
)
def orchestrator_invoke(message: str) -> dict:
    return {
        "status": "ok",
        "message": message
    }