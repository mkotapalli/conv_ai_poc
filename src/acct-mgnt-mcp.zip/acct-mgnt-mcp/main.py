from acct_mgnt_mcp import service

# IMPORTANT: ensure module fully loads tools at import time
MCP_SERVER = service.MCP_SERVER

if __name__ == "__main__":
    MCP_SERVER.run(transport="streamable-http")