import boto3
import requests
from requests_aws4auth import AWS4Auth

region = "us-east-1"
service = "bedrock-agentcore"

session = boto3.Session()
credentials = session.get_credentials()

auth = AWS4Auth(
    credentials.access_key,
    credentials.secret_key,
    region,
    service,
    session_token=credentials.token
)

url = "https://bcbs-dev-convai-gateway-e4ing1lwcu.gateway.bedrock-agentcore.us-east-1.amazonaws.com/mcp"

payload = {
    "jsonrpc": "2.0",
    "id": 1,
    "method": "tools/list"
}

response = requests.post(url, json=payload, auth=auth)

print(response.text)